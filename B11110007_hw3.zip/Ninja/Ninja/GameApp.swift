//
//  GameScene.swift
//  Ninja
//
//  Created by hpclab on 2025/3/24.
//

import SwiftUI


@main
struct GameApp: App{
    var body: some Scene {
        WindowGroup{
            
            GameView()
        }
    }
}
