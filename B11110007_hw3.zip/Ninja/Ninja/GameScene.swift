//
//  GameScene.swift
//  Ninja
//
//  Created by hpclab on 2025/3/24.
//
//
//
//class GameScene: SKScene {
//    override func didMove(to view: SKView) {
//        let background = SKSpriteNode(imageNamed: "sliceBackground")
//        background.position = CGPoint(x: 512, y: 384)
//        background.blendMode = .replace
//        background.zPosition = -1
//        addChild(background)
//        physicsWorld.gravity = CGVector(dx: 0, dy: -6)
//        physicsWorld.speed = 0.85
//        createScore()
//        createLives()
//        createSlices()
//    }
//
//    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
//    }
//}

