//
//  NinjaTests.swift
//  NinjaTests
//
//  Created by hpclab on 2025/3/24.
//

import Testing
@testable import Ninja

struct NinjaTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
