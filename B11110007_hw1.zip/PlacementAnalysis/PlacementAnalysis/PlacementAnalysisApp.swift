//
//  PlacementAnalysisApp.swift
//  PlacementAnalysis
//
//  Created by mac03 on 2025/2/28.
//

import SwiftUI

@main
struct PlacementAnalysisApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
